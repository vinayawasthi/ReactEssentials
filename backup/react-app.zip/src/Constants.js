export const API_MAKES = "http://localhost:5000/api/makes/";
export const API_FEATURES = "http://localhost:5000/api/features/";
export const API_VEHICLE = "http://localhost:5000/api/vehicles/";

export const API_VEHICLE_LIST = "http://localhost:5000/api/vehicles/";


