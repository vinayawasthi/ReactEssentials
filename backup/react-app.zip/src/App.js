import React, { useState } from 'react'
import Header from './shared/header/Header'
import Footer from './shared/footer/Footer'
import Vehicles from './components/Vehicles';
import AddOrUpdateVehicle from './components/AddOrUpdateVehicle';
import './shared/styles/app.css';

function App() {
  return (
    <React.Fragment>
      <Header name="Rajasthan" />
      {/* <AddOrUpdateVehicle vehicleId={1} key="121" /> */}
      <AddOrUpdateVehicle />
      {/* <Vehicles /> */}
      <Footer year={new Date().getFullYear()} />
    </React.Fragment>
  )
}

export default App;
